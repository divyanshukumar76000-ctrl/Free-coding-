package com.potionsmp;

import com.potionsmp.abilities.*;
import com.potionsmp.commands.*;
import com.potionsmp.hud.HudManager;
import com.potionsmp.listeners.*;
import com.potionsmp.managers.*;
import com.potionsmp.utils.PotionType;
import org.bukkit.plugin.java.JavaPlugin;

public class PotionSMP extends JavaPlugin {

    private static PotionSMP instance;

    private CooldownManager     cooldownManager;
    private HitCounterManager   hitCounterManager;
    private FrozenPlayerManager frozenPlayerManager;
    private FireAuraManager     fireAuraManager;
    private RegenAbilityManager regenAbilityManager;
    private EnderDomainManager  enderDomainManager;
    private ParticleManager     particleManager;
    private GlitchManager       glitchManager;
    private ShieldManager       shieldManager;
    private BossBarManager      bossBarManager;
    private SlotManager         slotManager;
    private AbilityRegistry     abilityRegistry;
    private HudManager          hudManager;
    private JumpListener        jumpListener;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // ── Managers ──────────────────────────────────────────────────────
        cooldownManager     = new CooldownManager();
        hitCounterManager   = new HitCounterManager();
        frozenPlayerManager = new FrozenPlayerManager(this); // self-registers events
        fireAuraManager     = new FireAuraManager(this);
        regenAbilityManager = new RegenAbilityManager(this);
        enderDomainManager  = new EnderDomainManager(this);
        particleManager     = new ParticleManager(this);
        glitchManager       = new GlitchManager(this);
        shieldManager       = new ShieldManager(this);
        bossBarManager      = new BossBarManager(this);
        slotManager         = new SlotManager();
        abilityRegistry     = new AbilityRegistry();
        hudManager          = new HudManager(this);
        jumpListener        = new JumpListener(this);

        // ── Listeners ─────────────────────────────────────────────────────
        var pm = getServer().getPluginManager();
        pm.registerEvents(new DrinkListener(this),  this);
        pm.registerEvents(new CombatListener(this), this);
        pm.registerEvents(jumpListener,              this);
        pm.registerEvents(new GUIListener(this),    this);

        // Abilities that also implement Listener — register them individually
        // NOTE: RegenAbility does NOT have a register() method — excluded intentionally
        registerAbilityListener(PotionType.ENDER,    EnderAbility.class);
        registerAbilityListener(PotionType.SPEED,    SpeedAbility.class);
        registerAbilityListener(PotionType.FEATHER,  FeatherAbility.class);
        registerAbilityListener(PotionType.EMERALD,  EmeraldAbility.class);
        registerAbilityListener(PotionType.STRENGTH, StrengthAbility.class);

        // ── Commands ──────────────────────────────────────────────────────
        // Primary fix for the startup NPE was adding 'swap' to plugin.yml's
        // commands: section (it was missing). These null-checks are just
        // defense-in-depth so a future plugin.yml edit fails loudly via the
        // log instead of crashing onEnable.
        PotionCommand potionCmd = new PotionCommand(this);
        registerCommand("potionsmp", potionCmd, potionCmd);
        registerCommand("slot1", new SlotCommand(this, SlotManager.SLOT_1), null);
        registerCommand("slot2", new SlotCommand(this, SlotManager.SLOT_2), null);
        registerCommand("swap", new SwapCommand(this), null);

        hudManager.start();

        getLogger().info("PotionSMP v3.0.0 enabled — 12 potions loaded.");
    }

    /**
     * Null-safe command registration. Logs a severe error (instead of
     * crashing onEnable with an NPE) if a command name isn't declared under
     * commands: in plugin.yml.
     */
    private void registerCommand(String name, org.bukkit.command.CommandExecutor executor,
                                  org.bukkit.command.TabCompleter tabCompleter) {
        org.bukkit.command.PluginCommand command = getCommand(name);
        if (command == null) {
            getLogger().severe("Command '" + name + "' is missing from plugin.yml! "
                + "It will not function until it is declared under commands: in plugin.yml.");
            return;
        }
        command.setExecutor(executor);
        if (tabCompleter != null) {
            command.setTabCompleter(tabCompleter);
        }
    }

    /**
     * Reflectively calls ability.register(plugin) for abilities that
     * implement Listener. Safe — logs warning and continues on failure.
     */
    private void registerAbilityListener(PotionType type, Class<?> clazz) {
        Ability ability = abilityRegistry.get(type);
        if (ability == null) return;
        try {
            clazz.getMethod("register", PotionSMP.class).invoke(ability, this);
        } catch (NoSuchMethodException ignored) {
            // Ability doesn't implement register() — skip silently
        } catch (Exception e) {
            getLogger().warning("[PotionSMP] Could not register listener for "
                + type.name() + ": " + e.getMessage());
        }
    }

    @Override
    public void onDisable() {
        frozenPlayerManager.unfreezeAll();
        fireAuraManager.cancelAll();
        enderDomainManager.cancelAll();
        particleManager.cancelAll();
        glitchManager.cancelAll();
        shieldManager.cancelAll();
        bossBarManager.removeAll();
        hudManager.stop();
        getLogger().info("PotionSMP disabled.");
    }

    // ── Accessors ─────────────────────────────────────────────────────────
    public static PotionSMP getInstance()                    { return instance; }
    public CooldownManager getCooldownManager()              { return cooldownManager; }
    public HitCounterManager getHitCounterManager()          { return hitCounterManager; }
    public FrozenPlayerManager getFrozenPlayerManager()      { return frozenPlayerManager; }
    public FireAuraManager getFireAuraManager()              { return fireAuraManager; }
    public RegenAbilityManager getRegenAbilityManager()      { return regenAbilityManager; }
    public EnderDomainManager getEnderDomainManager()        { return enderDomainManager; }
    public SlotManager getSlotManager()                      { return slotManager; }
    public AbilityRegistry getAbilityRegistry()              { return abilityRegistry; }
    public HudManager getHudManager()                        { return hudManager; }
    public ParticleManager getParticleManager()              { return particleManager; }
    public GlitchManager getGlitchManager()                  { return glitchManager; }
    public ShieldManager getShieldManager()                  { return shieldManager; }
    public BossBarManager getBossBarManager()                { return bossBarManager; }
    public JumpListener getJumpListener()                    { return jumpListener; }
}
