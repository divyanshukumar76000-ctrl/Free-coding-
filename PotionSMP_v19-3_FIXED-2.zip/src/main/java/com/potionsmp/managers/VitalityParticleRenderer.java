package com.potionsmp.managers;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Life Force Core / Vitality Surge particle renderer.
 *
 * PARTICLE ONLY.
 *
 * Does NOT:
 * - heal players
 * - modify health
 * - modify cooldowns
 * - modify duration
 * - modify damage
 * - modify potion mechanics
 *
 * Intended for Paper/Spigot 1.21.x / Java 21.
 */
public final class VitalityParticleRenderer {

    private static final double OUTER_RADIUS = 2.95;
    private static final double CORE_RADIUS = 0.45;

    private static final int DRAW_INTERVAL = 2;

    private static final int MAX_FLOATING_HEARTS = 4;

    private static final double TWO_PI = Math.PI * 2.0;

    private final JavaPlugin plugin;

    private final Map<UUID, BukkitTask> activeTasks =
            new ConcurrentHashMap<>();

    private final Map<UUID, Long> activeSince =
            new ConcurrentHashMap<>();

    private final Map<UUID, List<FloatingHeart>> floatingHearts =
            new ConcurrentHashMap<>();

    private final Random random = new Random();

    public VitalityParticleRenderer(JavaPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin);
    }

    /* =========================================================
       PUBLIC API
       ========================================================= */

    /**
     * Starts the visual-only Vitality Surge animation.
     *
     * IMPORTANT:
     * This method does not activate gameplay.
     */
    public void start(Player player) {

        if (player == null || !player.isOnline()) {
            return;
        }

        UUID uuid = player.getUniqueId();

        // Prevent duplicate particle tasks.
        stop(uuid);

        activeSince.put(uuid, System.currentTimeMillis());
        floatingHearts.put(uuid, new ArrayList<>());

        BukkitTask task = new BukkitRunnable() {

            private int tick = 0;

            @Override
            public void run() {

                if (!player.isOnline()
                        || player.isDead()
                        || !player.isValid()) {

                    stop(uuid);
                    cancel();
                    return;
                }

                Location center = player.getLocation();

                if (center.getWorld() == null) {
                    stop(uuid);
                    cancel();
                    return;
                }

                int currentTick = tick;

                if (currentTick < 8) {

                    renderAwakening(player, currentTick);

                } else if (currentTick < 18) {

                    renderHeartFormation(player, currentTick - 8);

                } else if (currentTick < 32) {

                    renderSurge(player, currentTick - 18);

                } else {

                    renderSustained(player, currentTick);
                }

                tick += DRAW_INTERVAL;
            }

        }.runTaskTimer(plugin, 0L, DRAW_INTERVAL);

        activeTasks.put(uuid, task);
    }

    /**
     * Starts only the passive Life Force visual.
     */
    public void startPassive(Player player) {

        if (player == null || !player.isOnline()) {
            return;
        }

        UUID uuid = player.getUniqueId();

        // Passive should have its own renderer task.
        BukkitTask existing = activeTasks.get(uuid);

        if (existing != null) {
            return;
        }

        BukkitTask task = new BukkitRunnable() {

            private int tick = 0;

            @Override
            public void run() {

                if (!player.isOnline()
                        || player.isDead()
                        || !player.isValid()) {

                    cancel();
                    activeTasks.remove(uuid);
                    return;
                }

                renderPassive(player, tick);

                tick += DRAW_INTERVAL;
            }

        }.runTaskTimer(plugin, 0L, DRAW_INTERVAL);

        activeTasks.put(uuid, task);
    }

    /**
     * Visual-only ending animation.
     *
     * Call this when the EXISTING gameplay ability ends.
     */
    public void playEndAnimation(Player player) {

        if (player == null || !player.isOnline()) {
            return;
        }

        UUID uuid = player.getUniqueId();

        BukkitTask old = activeTasks.remove(uuid);

        if (old != null) {
            old.cancel();
        }

        floatingHearts.remove(uuid);
        activeSince.remove(uuid);

        new BukkitRunnable() {

            private int tick = 0;

            @Override
            public void run() {

                if (!player.isOnline()
                        || player.isDead()
                        || !player.isValid()) {

                    cancel();
                    return;
                }

                renderEnding(player, tick);

                tick += DRAW_INTERVAL;

                if (tick >= 16) {
                    cancel();
                }
            }

        }.runTaskTimer(plugin, 0L, DRAW_INTERVAL);
    }

    /**
     * Small visual feedback for successful healing/blocking.
     *
     * This method does NOT perform healing.
     */
    public void playHealingImpact(Player player) {

        if (player == null || !player.isOnline()) {
            return;
        }

        Location center = chestLocation(player);

        if (center.getWorld() == null) {
            return;
        }

        World world = center.getWorld();

        // White flash.
        world.spawnParticle(
                Particle.DUST,
                center,
                7,
                0.15,
                0.15,
                0.15,
                0.0,
                dust(Color.WHITE, 1.2F)
        );

        // Green ripple.
        for (int i = 0; i < 8; i++) {

            double angle = TWO_PI * i / 8.0;

            double radius = 0.25;

            Location point = center.clone().add(
                    Math.cos(angle) * radius,
                    0.0,
                    Math.sin(angle) * radius
            );

            world.spawnParticle(
                    Particle.HAPPY_VILLAGER,
                    point,
                    1,
                    0,
                    0,
                    0,
                    0
            );
        }

        // Tiny red/pink core flash.
        world.spawnParticle(
                Particle.DUST,
                center,
                5,
                0.08,
                0.08,
                0.08,
                0.0,
                dust(Color.fromRGB(255, 80, 130), 1.4F)
        );
    }

    /**
     * Stops all particle rendering for a player.
     */
    public void stop(Player player) {

        if (player != null) {
            stop(player.getUniqueId());
        }
    }

    /**
     * Stops renderer using UUID.
     */
    public void stop(UUID uuid) {

        BukkitTask task = activeTasks.remove(uuid);

        if (task != null) {
            task.cancel();
        }

        activeSince.remove(uuid);
        floatingHearts.remove(uuid);
    }

    /**
     * Plugin shutdown cleanup.
     */
    public void shutdown() {

        for (BukkitTask task : activeTasks.values()) {
            task.cancel();
        }

        activeTasks.clear();
        activeSince.clear();
        floatingHearts.clear();
    }

    /* =========================================================
       ACTIVATION
       ========================================================= */

    private void renderAwakening(Player player, int tick) {

        Location feet = player.getLocation().clone();

        World world = feet.getWorld();

        if (world == null) {
            return;
        }

        double progress = tick / 8.0;

        // 6–8 controlled particles.
        int count = 7;

        for (int i = 0; i < count; i++) {

            double angle =
                    (TWO_PI * i / count)
                            + tick * 0.12;

            double radius =
                    0.35 + progress * 0.45;

            double y =
                    0.08 + progress * 1.65;

            Location point = feet.clone().add(
                    Math.cos(angle) * radius,
                    y,
                    Math.sin(angle) * radius
            );

            world.spawnParticle(
                    Particle.DUST,
                    point,
                    1,
                    0,
                    0,
                    0,
                    0,
                    dust(Color.fromRGB(90, 255, 110), 1.0F)
            );
        }

        // Tiny upward regeneration accents.
        if (tick % 4 == 0) {

            world.spawnParticle(
                    Particle.HAPPY_VILLAGER,
                    feet.clone().add(0, 0.15, 0),
                    1,
                    0.15,
                    0.05,
                    0.15,
                    0
            );
        }
    }

    /* =========================================================
       HEART FORMATION
       ========================================================= */

    private void renderHeartFormation(Player player, int tick) {

        Location center = chestLocation(player);

        World world = center.getWorld();

        if (world == null) {
            return;
        }

        double progress =
                Math.min(1.0, tick / 10.0);

        double radius =
                1.1 * (1.0 - easeOut(progress));

        for (int i = 0; i < 8; i++) {

            double angle =
                    TWO_PI * i / 8.0
                            + tick * 0.20;

            Location point =
                    center.clone().add(
                            Math.cos(angle) * radius,
                            Math.sin(angle * 2.0) * 0.15,
                            Math.sin(angle) * radius
                    );

            world.spawnParticle(
                    Particle.DUST,
                    point,
                    1,
                    0,
                    0,
                    0,
                    0,
                    dust(
                            Color.fromRGB(255, 70, 125),
                            1.2F
                    )
            );
        }

        // Short heart flash.
        if (tick == 8) {

            world.spawnParticle(
                    Particle.HEART,
                    center.clone().add(0, 0.05, 0),
                    1,
                    0,
                    0,
                    0,
                    0
            );

            world.spawnParticle(
                    Particle.DUST,
                    center,
                    10,
                    0.18,
                    0.18,
                    0.18,
                    0,
                    dust(Color.WHITE, 1.3F)
            );
        }
    }

    /* =========================================================
       SURGE
       ========================================================= */

    private void renderSurge(Player player, int tick) {

        Location center = chestLocation(player);

        World world = center.getWorld();

        if (world == null) {
            return;
        }

        double progress =
                Math.min(1.0, tick / 14.0);

        double eased =
                easeOut(progress);

        double ringRadius =
                0.25 + OUTER_RADIUS * eased;

        renderLifeRing(
                world,
                center,
                ringRadius,
                tick * 0.045,
                0.85
        );

        renderSpiral(
                world,
                player,
                tick,
                true
        );

        renderSpiral(
                world,
                player,
                tick,
                false
        );

        // 3–5 hearts during surge.
        if (tick == 4
                || tick == 8
                || tick == 12) {

            spawnFloatingHeart(player);
        }

        renderLifeCore(world, center, tick);
    }

    /* =========================================================
       SUSTAINED EFFECT
       ========================================================= */

    private void renderSustained(Player player, int tick) {

        Location center = chestLocation(player);

        World world = center.getWorld();

        if (world == null) {
            return;
        }

        // Main 4-segment ring.
        renderLifeRing(
                world,
                center,
                OUTER_RADIUS,
                tick * 0.018,
                1.0
        );

        // Opposite green spirals.
        renderSpiral(
                world,
                player,
                tick,
                true
        );

        renderSpiral(
                world,
                player,
                tick,
                false
        );

        // Central life core.
        renderLifeCore(
                world,
                center,
                tick
        );

        // Floating hearts.
        updateFloatingHearts(player);

        // Sparse healing sparks.
        if (tick % 50 == 0) {
            renderHealingSpark(world, center, tick);
        }

        // Occasional white/gold highlight.
        if (tick % 70 == 0) {

            world.spawnParticle(
                    Particle.DUST,
                    center,
                    2,
                    0.12,
                    0.12,
                    0.12,
                    0,
                    dust(
                            Color.fromRGB(255, 230, 130),
                            1.0F
                    )
            );
        }
    }

    /* =========================================================
       MAIN LIFE RING
       ========================================================= */

    private void renderLifeRing(
            World world,
            Location center,
            double radius,
            double rotation,
            double intensity
    ) {

        /*
         * 4 curved segments.
         *
         * Each segment has a gap.
         */
        final int segments = 4;

        final double segmentLength =
                Math.toRadians(63);

        final double gap =
                Math.toRadians(27);

        /*
         * Low particle count.
         *
         * Approximately:
         * 4 segments × 6 particles = 24 particles
         * every 2 ticks.
         */
        final int pointsPerSegment = 6;

        for (int segment = 0; segment < segments; segment++) {

            double start =
                    segment * (segmentLength + gap)
                            + rotation;

            for (int i = 0; i < pointsPerSegment; i++) {

                double t =
                        i / (double) (pointsPerSegment - 1);

                double angle =
                        start + segmentLength * t;

                Location point =
                        center.clone().add(
                                Math.cos(angle) * radius,
                                0,
                                Math.sin(angle) * radius
                        );

                Color color;

                if (i == 0
                        || i == pointsPerSegment - 1) {

                    color = Color.WHITE;

                } else if (i % 3 == 0) {

                    color = Color.fromRGB(
                            255,
                            90,
                            145
                    );

                } else {

                    color = Color.fromRGB(
                            210,
                            35,
                            90
                    );
                }

                world.spawnParticle(
                        Particle.DUST,
                        point,
                        1,
                        0,
                        0,
                        0,
                        0,
                        dust(
                                color,
                                (float) (0.75 + intensity * 0.35)
                        )
                );
            }
        }
    }

    /* =========================================================
       LIFE CORE
       ========================================================= */

    private void renderLifeCore(
            World world,
            Location center,
            int tick
    ) {

        /*
         * Smooth pulse.
         */
        double pulse =
                (Math.sin(tick * 0.10) + 1.0) * 0.5;

        double radius =
                CORE_RADIUS * (0.75 + pulse * 0.25);

        float size =
                (float) (1.0 + pulse * 0.8);

        Location core =
                center.clone().add(0, 0.05, 0);

        world.spawnParticle(
                Particle.DUST,
                core,
                2,
                radius * 0.15,
                radius * 0.15,
                radius * 0.15,
                0,
                dust(
                        Color.fromRGB(
                                255,
                                65,
                                120
                        ),
                        size
                )
        );

        // Very rare heart accent.
        if (tick % 90 == 0) {

            world.spawnParticle(
                    Particle.HEART,
                    core.clone().add(0, 0.1, 0),
                    1,
                    0,
                    0,
                    0,
                    0
            );
        }
    }

    /* =========================================================
       GREEN LIFE SPIRAL
       ========================================================= */

    private void renderSpiral(
            World world,
            Player player,
            int tick,
            boolean clockwise
    ) {

        Location base =
                player.getLocation();

        double direction =
                clockwise ? 1.0 : -1.0;

        /*
         * Two thin opposing spirals.
         *
         * Low density:
         * 5 points per spiral.
         */
        final int points = 5;

        for (int i = 0; i < points; i++) {

            double progress =
                    i / (double) points;

            /*
             * Ground → chest.
             */
            double y =
                    0.15 + progress * 1.75;

            /*
             * Spiral radius.
             */
            double radius =
                    0.55
                            + Math.sin(
                            progress * Math.PI
                    ) * 0.35;

            double angle =
                    direction *
                            (
                                    tick * 0.075
                                            + progress * TWO_PI * 1.15
                            );

            Location point =
                    base.clone().add(
                            Math.cos(angle) * radius,
                            y,
                            Math.sin(angle) * radius
                    );

            Color color =
                    i % 2 == 0
                            ? Color.fromRGB(
                            90,
                            255,
                            100
                    )
                            : Color.fromRGB(
                            160,
                            255,
                            70
                    );

            world.spawnParticle(
                    Particle.DUST,
                    point,
                    1,
                    0,
                    0,
                    0,
                    0,
                    dust(color, 1.0F)
            );
        }
    }

    /* =========================================================
       FLOATING HEARTS
       ========================================================= */

    private void spawnFloatingHeart(Player player) {

        UUID uuid = player.getUniqueId();

        List<FloatingHeart> hearts =
                floatingHearts.computeIfAbsent(
                        uuid,
                        k -> new ArrayList<>()
                );

        if (hearts.size() >= MAX_FLOATING_HEARTS) {
            return;
        }

        double angle = random.nextDouble() * TWO_PI;
        double radius = 0.6 + random.nextDouble() * 0.5;
        int maxLife = 30 + random.nextInt(20);

        hearts.add(new FloatingHeart(angle, radius, maxLife));
    }

    private void updateFloatingHearts(Player player) {

        UUID uuid = player.getUniqueId();

        List<FloatingHeart> hearts = floatingHearts.get(uuid);

        if (hearts == null || hearts.isEmpty()) {
            return;
        }

        Location center = chestLocation(player);
        World world = center.getWorld();

        if (world == null) {
            return;
        }

        Iterator<FloatingHeart> it = hearts.iterator();

        while (it.hasNext()) {

            FloatingHeart heart = it.next();

            double progress =
                    heart.life / (double) heart.maxLife;

            double y =
                    progress * 1.1;

            double radius =
                    heart.radius * (1.0 - progress * 0.4);

            double angle =
                    heart.angle + heart.life * 0.08;

            Location point =
                    center.clone().add(
                            Math.cos(angle) * radius,
                            y,
                            Math.sin(angle) * radius
                    );

            world.spawnParticle(
                    Particle.HEART,
                    point,
                    1,
                    0,
                    0,
                    0,
                    0
            );

            heart.life += DRAW_INTERVAL;

            if (heart.isExpired()) {
                it.remove();
            }
        }
    }

    private static final class FloatingHeart {

        final double angle;
        final double radius;
        final int maxLife;
        int life;

        FloatingHeart(double angle, double radius, int maxLife) {
            this.angle = angle;
            this.radius = radius;
            this.maxLife = maxLife;
            this.life = 0;
        }

        boolean isExpired() {
            return life >= maxLife;
        }
    }

    /* =========================================================
       PASSIVE
       ========================================================= */

    private void renderPassive(Player player, int tick) {

        Location center = chestLocation(player);

        World world = center.getWorld();

        if (world == null) {
            return;
        }

        // Slow single orbiting mote — deliberately sparse for an
        // always-on passive.
        if (tick % 20 == 0) {

            double angle = tick * 0.05;

            Location point = center.clone().add(
                    Math.cos(angle) * 0.5,
                    0,
                    Math.sin(angle) * 0.5
            );

            world.spawnParticle(
                    Particle.HAPPY_VILLAGER,
                    point,
                    1,
                    0.1,
                    0.1,
                    0.1,
                    0
            );
        }

        if (tick % 60 == 0) {

            world.spawnParticle(
                    Particle.DUST,
                    center,
                    1,
                    0.1,
                    0.1,
                    0.1,
                    0,
                    dust(Color.fromRGB(255, 90, 140), 0.6F)
            );
        }
    }

    /* =========================================================
       ENDING / COLLAPSE
       ========================================================= */

    private void renderEnding(Player player, int tick) {

        Location center = chestLocation(player);

        World world = center.getWorld();

        if (world == null) {
            return;
        }

        double progress =
                Math.min(1.0, tick / 16.0);

        double radius =
                OUTER_RADIUS * (1.0 - progress);

        for (int i = 0; i < 10; i++) {

            double angle =
                    TWO_PI * i / 10.0
                            + tick * 0.15;

            Location point =
                    center.clone().add(
                            Math.cos(angle) * radius,
                            0,
                            Math.sin(angle) * radius
                    );

            world.spawnParticle(
                    Particle.DUST,
                    point,
                    1,
                    0,
                    0,
                    0,
                    0,
                    dust(
                            Color.fromRGB(255, 70, 125),
                            (float) (0.4 + (1.0 - progress) * 1.0)
                    )
            );
        }

        if (tick == 0) {

            world.spawnParticle(
                    Particle.HEART,
                    center.clone().add(0, 0.1, 0),
                    3,
                    0.2,
                    0.2,
                    0.2,
                    0
            );
        }
    }

    /* =========================================================
       HEALING SPARK (sparse ambient)
       ========================================================= */

    private void renderHealingSpark(
            World world,
            Location center,
            int tick
    ) {

        double angle = tick * 0.05;
        double radius = OUTER_RADIUS * 0.6;

        Location point = center.clone().add(
                Math.cos(angle) * radius,
                0.3,
                Math.sin(angle) * radius
        );

        world.spawnParticle(
                Particle.HAPPY_VILLAGER,
                point,
                2,
                0.1,
                0.1,
                0.1,
                0
        );
    }

    /* =========================================================
       HELPERS
       ========================================================= */

    private Location chestLocation(Player player) {
        return player.getLocation().clone().add(0, 1.1, 0);
    }

    private double easeOut(double t) {
        return 1.0 - Math.pow(1.0 - t, 3.0);
    }

    private static Particle.DustOptions dust(Color color, float size) {
        return new Particle.DustOptions(color, size);
    }
}
