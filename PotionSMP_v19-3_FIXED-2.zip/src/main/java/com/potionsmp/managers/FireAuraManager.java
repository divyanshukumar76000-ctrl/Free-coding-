package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Manages the Fire Potion's "Inferno Rage" active ability.
 * Pure aura effect - no blocks are placed or modified. A moving circular zone
 * around the player damages + ignites any player/mob standing inside it,
 * visualized with particles only.
 */
public class FireAuraManager {

    private final PotionSMP plugin;
    private final Map<UUID, Integer> activeTasks = new HashMap<>();
    private final Random random = new Random();

    public FireAuraManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void activateInfernoAura(Player player, int durationTicks, int radius) {
        UUID uid = player.getUniqueId();
        double dps = plugin.getConfig().getDouble("potions.fire.damage-per-second", 2.0);

        Integer existing = activeTasks.remove(uid);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);

        BukkitRunnable auraTask = new BukkitRunnable() {
            int ticks = 0;
            // Visual-only rotation state (does not affect damage/timing logic below).
            double rotation = random.nextDouble() * 360.0;

            @Override
            public void run() {
                if (ticks >= durationTicks || !player.isOnline()) {
                    activeTasks.remove(uid);
                    cancel();
                    return;
                }

                Location center = player.getLocation();

                if (ticks % 20 == 0) {
                    for (Entity e : center.getWorld().getNearbyEntities(center, radius, 2.5, radius)) {
                        if (e instanceof LivingEntity le && !e.getUniqueId().equals(uid)) {
                            le.damage(dps, player);
                            le.setFireTicks(40);
                        }
                    }
                }

                // Smooth rotation advances every tick, independent of draw throttling,
                // so the ring's spin stays fluid even though it's only rendered every
                // RING_INTERVAL_TICKS ticks.
                rotation = (rotation + ROTATION_PER_TICK) % 360.0;

                if (ticks % RING_INTERVAL_TICKS == 0) {
                    drawSectorRing(player, center, rotation);
                }

                ticks++;
            }
        };

        int taskId = auraTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        activeTasks.put(uid, taskId);
    }

    // ── Flat ring geometry ──────────────────────────────────────────────
    // Fixed visual radius/diameter per spec — independent of the gameplay
    // damage radius (potions.fire.active-fire-radius), which is untouched.
    // 10-block diameter = 5-block radius.
    private static final double RING_RADIUS = 5.0;
    // Feet / ground level offset — a hair off the ground to avoid z-fighting.
    private static final double Y_OFFSET = 0.1;
    // Draw the ring 5x/second (every 4 ticks) instead of every tick (20x/sec)
    // — keeps particle volume low and avoids the FPS drop seen in testing.
    private static final int RING_INTERVAL_TICKS = 4;

    // Four separated 90° sections, each with a small gap so they read as
    // distinct arcs rather than one solid circle.
    private static final int ARC_COUNT = 4;
    private static final double SECTION_SIZE = 360.0 / ARC_COUNT; // 90°
    private static final double ARC_GAP = 12.0;                   // gap per section
    private static final double ARC_SPAN = SECTION_SIZE - ARC_GAP; // visible arc size
    private static final int ARC_POINTS = 6;                       // points per arc

    // Smooth continuous spin: 360° over 36 ticks (1.8s) at 10°/tick.
    private static final double ROTATION_PER_TICK = 10.0;

    private static final Particle.DustOptions ORANGE_CORE =
            new Particle.DustOptions(Color.fromRGB(255, 120, 20), 0.7f);

    /**
     * Draws a FLAT horizontal ring at the player's feet/ground level,
     * player exactly centered. Radius 5 / diameter 10, using the required
     * x = centerX + r*cos(angle), z = centerZ + r*sin(angle) formula. Y is a
     * single fixed value per draw call — never part of the angle loop — so
     * this cannot render as a vertical circle, cylinder, or sphere.
     *
     * The ring is split into 4 separated 90° arcs (with a visible gap
     * between each) that rotate together smoothly around the player.
     * Alternating particle type per arc keeps all 4 sections visually
     * distinguishable, and a sparse orange dust core plus occasional
     * embers give the ring a cleaner, more "designed" flame look without
     * raising the particle count.
     */
    private void drawSectorRing(Player player, Location center, double rotation) {
        double y = center.getY() + Y_OFFSET;
        World world = center.getWorld();

        for (int section = 0; section < ARC_COUNT; section++) {
            double gapOffset = (SECTION_SIZE - ARC_SPAN) / 2.0;
            double startAngle = rotation + section * SECTION_SIZE + gapOffset;
            Particle arcParticle = (section % 2 == 0) ? Particle.FLAME : Particle.SOUL_FIRE_FLAME;

            for (int point = 0; point < ARC_POINTS; point++) {
                double progress = point / (double) (ARC_POINTS - 1);
                double angle = Math.toRadians(startAngle + ARC_SPAN * progress);

                double x = center.getX() + RING_RADIUS * Math.cos(angle);
                double z = center.getZ() + RING_RADIUS * Math.sin(angle);

                world.spawnParticle(arcParticle, x, y, z, 1, 0, 0, 0, 0);

                // Orange heat core on alternating points only — keeps the
                // ring looking hot without doubling the particle count.
                if (point % 2 == 0) {
                    world.spawnParticle(Particle.DUST, x, y + 0.02, z, 1, ORANGE_CORE);
                }
            }
        }

        // Occasional rising ember off the ring edge — sparse, not per-point.
        if (random.nextInt(3) == 0) {
            double emberAngle = Math.toRadians(rotation + random.nextDouble() * 360.0);
            double ex = center.getX() + RING_RADIUS * Math.cos(emberAngle);
            double ez = center.getZ() + RING_RADIUS * Math.sin(emberAngle);
            world.spawnParticle(Particle.SMALL_FLAME, ex, y + 0.15, ez, 0, 0, 0.06, 0, 1);
        }

        // Small center wisp so the player still visibly reads as "on fire",
        // throttled to the same interval as the ring to keep density low.
        world.spawnParticle(Particle.FLAME, center.clone().add(0, 0.1, 0), 2, 0.2, 0, 0.2, 0.01);
    }

    public void cancelAura(UUID uid) {
        Integer taskId = activeTasks.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
    }

    public void cancelAll() {
        for (int id : activeTasks.values()) {
            plugin.getServer().getScheduler().cancelTask(id);
        }
        activeTasks.clear();
    }
}
