package com.potionsmp.hud;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.Style;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.EnumMap;
import java.util.Map;

/**
 * Renders a 2-slot HUD above the hotbar via ActionBar every 10 ticks.
 *
 * Font : minecraft:default  (assets/minecraft/font/default.json)
 * Textures: assets/minecraft/textures/potions/*.png
 *
 * ARCHITECTURE — one complete glyph per slot state (no overlay/negative-space
 * trick). Each PNG already bakes in its own frame/border + icon art as a
 * single flattened image, so a slot is always rendered as exactly ONE
 * character:
 *   \uE901          → empty slot (complete empty box glyph)
 *   \uE002 – \uE00D  → potion ready (complete box+icon glyph, per type)
 *   \uE202 – \uE20D  → potion on cooldown (complete darkened box+icon glyph)
 *
 * Glyph map (must match assets/minecraft/font/default.json exactly):
 *   glitch    \uE002 / \uE202      shield    \uE003 / \uE203
 *   freeze    \uE004 / \uE204      ender     \uE005 / \uE205
 *   fire      \uE006 / \uE206      teleport  \uE007 / \uE207
 *   regen     \uE008 / \uE208      speed     \uE009 / \uE209
 *   feather   \uE00A / \uE20A      emerald   \uE00B / \uE20B
 *   strength  \uE00C / \uE20C      haste     \uE00D / \uE20D
 *
 * Space chars:
 *   \uE904 = +2 px (after every slot glyph)   \uE905 = +6 px (gap between slots)
 *
 * HUD always renders for ALL online players — even if both slots are empty.
 *
 * Cooldown display: dark icon + " 45s" (yellow text, icon itself unmodified —
 * no NamedTextColor tint is applied to slot glyphs since their color is
 * already baked into the PNG).
 * Ready display   : icon only, no text.
 */
public class HudManager {

    // ── Font key ──────────────────────────────────────────────────────────
    private static final Key FONT = Key.key("minecraft", "default");

    // ── Slot background ───────────────────────────────────────────────────
    private static final String SLOT_EMPTY = "\uE901";

    // ── Space chars ───────────────────────────────────────────────────────
    private static final String SP2 = "\uE904"; // +2 px
    private static final String SP6 = "\uE905"; // +6 px

    // ── Icon record: normal char + cooldown (dark) char ────────────────────
    // NOTE: no color field anymore — every icon PNG (normal + dark) already
    // bakes in its own full-color artwork + frame. Applying a NamedTextColor
    // on top would multiply-tint the baked pixels and distort the art, so
    // these glyphs are always rendered at default (white/no-tint).
    private record IconInfo(String normal, String dark) {}

    private static final Map<PotionType, IconInfo> ICONS = new EnumMap<>(PotionType.class);
    static {
        // Existing potions — chars confirmed from resource pack
        ICONS.put(PotionType.FIRE,     new IconInfo("\uE006", "\uE206"));
        ICONS.put(PotionType.FREEZE,   new IconInfo("\uE004", "\uE204"));
        ICONS.put(PotionType.REGEN,    new IconInfo("\uE008", "\uE208"));
        ICONS.put(PotionType.GLITCH,   new IconInfo("\uE002", "\uE202"));
        ICONS.put(PotionType.SHIELD,   new IconInfo("\uE003", "\uE203"));
        ICONS.put(PotionType.ENDER,    new IconInfo("\uE005", "\uE205"));
        ICONS.put(PotionType.TELEPORT, new IconInfo("\uE007", "\uE207"));

        // New potions — rows 8–12 of effects.png
        ICONS.put(PotionType.SPEED,    new IconInfo("\uE009", "\uE209"));
        ICONS.put(PotionType.FEATHER,  new IconInfo("\uE00A", "\uE20A"));
        ICONS.put(PotionType.EMERALD,  new IconInfo("\uE00B", "\uE20B"));
        ICONS.put(PotionType.STRENGTH, new IconInfo("\uE00C", "\uE20C"));
        ICONS.put(PotionType.HASTE,    new IconInfo("\uE00D", "\uE20D"));
    }

    private final PotionSMP plugin;
    private BukkitTask task;

    public HudManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 0L, 10L);
    }

    public void stop() {
        if (task != null) { task.cancel(); task = null; }
    }

    // ── Tick: send to ALL online players, always ──────────────────────────

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendActionBar(buildHUD(player));
        }
    }

    /**
     * Instant one-shot update for a single player (used by /swap command).
     */
    public void sendOnce(Player player) {
        player.sendActionBar(buildHUD(player));
    }

    // ── HUD builder ───────────────────────────────────────────────────────

    /**
     * Always renders:  [Slot1]  SP6  [Slot2]
     * Both slots are shown regardless of whether they are empty.
     */
    private Component buildHUD(Player player) {
        PotionType slot1 = plugin.getSlotManager().getSlot1(player.getUniqueId());
        PotionType slot2 = plugin.getSlotManager().getSlot2(player.getUniqueId());

        Style font = Style.style().font(FONT).build();

        return Component.empty()
                .append(buildSlot(player, slot1, font))
                .append(Component.text(SP6).style(font))  // gap between slots
                .append(buildSlot(player, slot2, font));
    }

    /**
     * Builds a single slot component:
     *   null type  → empty background (\uE901)
     *   ready      → normal icon, no text
     *   cooldown   → dark icon + yellow " 45s" suffix
     */
    private Component buildSlot(Player player, PotionType type, Style fontStyle) {
        if (type == null) {
            return Component.text(SLOT_EMPTY + SP2).style(fontStyle);
        }

        IconInfo info = ICONS.getOrDefault(type,
            new IconInfo(SLOT_EMPTY, SLOT_EMPTY));

        boolean onCooldown = plugin.getCooldownManager()
                .isOnCooldown(player.getUniqueId(), type);

        if (onCooldown) {
            long secs = plugin.getCooldownManager()
                    .getRemainingSeconds(player.getUniqueId(), type);
            // Dark icon (its own composited PNG, already darkened) + cooldown seconds
            return Component.empty()
                    .append(Component.text(info.dark() + SP2).style(fontStyle))
                    .append(Component.text(secs + "s", NamedTextColor.YELLOW));
        }

        // Ready: just the normal icon, no text
        return Component.text(info.normal() + SP2)
                .style(fontStyle);
    }
}
