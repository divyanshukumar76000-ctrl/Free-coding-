package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Feather Potion — plugin-controlled, Elytra-like flight WITHOUT ever
 * giving/equipping an actual Elytra item. This is the ONLY Feather flight
 * system in the codebase; the old "slow descent while falling" glide loop
 * has been fully removed (see FeatherAbility.java).
 *
 * Activation: the player must have Feather equipped, be airborne (not on
 * ground, not in water/lava), and be at least `flight-min-altitude` blocks
 * above the nearest solid ground below them. Altitude is measured with a
 * downward ray trace, not just onGround()/a fixed Y check.
 *
 * While flying: velocity is recomputed every tick directly from the
 * player's look direction (pitch + yaw), so steering is "look where you
 * want to go" exactly like vanilla Elytra. Pitch also drives a smooth
 * dive-speed-up / climb-slow-down curve, both clamped by config so there's
 * no unbounded speed exploit.
 *
 * This manager never touches the player's chest slot / inventory — flight
 * is achieved purely by overriding velocity every tick, not by giving an
 * Elytra.
 */
public class FeatherFlightManager {

    private final PotionSMP plugin;

    private final Map<UUID, BukkitTask> flightTasks = new HashMap<>();
    private final Map<UUID, Double> currentSpeed = new HashMap<>();

    // Short grace window after flight ends during which fall damage is
    // still cancelled (covers the same-tick landing case where the
    // EntityDamageEvent for FALL can fire right as/just after we stop the
    // task). Cleared automatically a few ticks later — this is NOT a
    // standing fall-damage immunity, just a landing-frame safety net.
    private final Set<UUID> recentlyFlying = new HashSet<>();

    public FeatherFlightManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public boolean isFlying(UUID uid) {
        return flightTasks.containsKey(uid);
    }

    /**
     * Whether fall damage should be cancelled right now for this player —
     * true only while actively flying, or within the brief landing-frame
     * grace window right after flight ends. Never true just because
     * Feather is equipped.
     */
    public boolean shouldCancelFallDamage(UUID uid) {
        return flightTasks.containsKey(uid) || recentlyFlying.contains(uid);
    }

    /**
     * Call on player movement (and right after equip) to check whether
     * flight should start. No-op if already flying or not eligible.
     */
    public void tryStartFlight(Player player) {
        UUID uid = player.getUniqueId();
        if (flightTasks.containsKey(uid)) return;
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.FEATHER)) return;
        if (player.isOnGround()) return;
        if (isInLiquid(player)) return;

        // Don't fight vanilla creative/spectator flight.
        GameMode mode = player.getGameMode();
        if (mode == GameMode.CREATIVE || mode == GameMode.SPECTATOR) return;

        double minAltitude = plugin.getConfig().getDouble("potions.feather.flight-min-altitude", 5.0);
        if (distanceToGround(player) < minAltitude) return;

        startFlight(player);
    }

    private void startFlight(Player player) {
        UUID uid = player.getUniqueId();
        double baseSpeed = plugin.getConfig().getDouble("potions.feather.flight-base-speed", 0.5);
        currentSpeed.put(uid, baseSpeed);
        recentlyFlying.remove(uid);

        BukkitRunnable task = new BukkitRunnable() {
            int ticksSinceParticle = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead()) {
                    stopFlight(player);
                    return;
                }
                if (!plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.FEATHER)) {
                    stopFlight(player);
                    return;
                }
                if (isInLiquid(player)) {
                    stopFlight(player);
                    return;
                }
                if (player.isOnGround()) {
                    playLandingEffect(player);
                    stopFlight(player);
                    return;
                }

                tickFlight(player);

                int particleInterval = plugin.getConfig()
                    .getInt("potions.feather.flight-particle-interval-ticks", 3);
                if (++ticksSinceParticle >= particleInterval) {
                    ticksSinceParticle = 0;
                    spawnTrailParticles(player);
                }
            }
        };

        BukkitTask handle = task.runTaskTimer(plugin, 0L, 1L);
        flightTasks.put(uid, handle);
    }

    /**
     * One tick of Elytra-like flight physics. Velocity is derived entirely
     * from the player's current look direction (yaw handles left/right
     * steering automatically; pitch drives dive/climb). No Elytra item or
     * gliding flag is used — this fully replaces vanilla glide physics.
     */
    private void tickFlight(Player player) {
        UUID uid = player.getUniqueId();
        Vector look = player.getEyeLocation().getDirection().clone().normalize();

        // Bukkit pitch: -90 (straight up) .. 0 (level) .. 90 (straight down)
        float pitch = player.getLocation().getPitch();
        double diveFactor = clamp(pitch / 90.0, -1.0, 1.0); // >0 diving, <0 climbing

        double baseSpeed   = plugin.getConfig().getDouble("potions.feather.flight-base-speed", 0.5);
        double maxSpeed     = plugin.getConfig().getDouble("potions.feather.flight-max-speed", 1.4);
        double diveAccel    = plugin.getConfig().getDouble("potions.feather.flight-dive-acceleration", 0.03);
        double decel        = plugin.getConfig().getDouble("potions.feather.flight-deceleration", 0.02);
        double climbMaxSpeed= plugin.getConfig().getDouble("potions.feather.flight-climb-max-speed", 0.5);
        double minSpeed     = baseSpeed * 0.6;

        double speed = currentSpeed.getOrDefault(uid, baseSpeed);

        if (diveFactor > 0.05) {
            // Looking down: gradually build up speed, steeper dive = faster buildup.
            speed += diveAccel * diveFactor;
        } else {
            // Level or climbing: smoothly bleed speed back toward baseline.
            speed -= decel;
        }
        speed = clamp(speed, minSpeed, maxSpeed);
        currentSpeed.put(uid, speed);

        Vector velocity = look.multiply(speed);

        // Reasonable maximum climb rate — looking straight up shouldn't
        // rocket the player upward at full flight speed.
        if (velocity.getY() > climbMaxSpeed) {
            velocity.setY(climbMaxSpeed);
        }

        player.setVelocity(velocity);
        // Continuously reset fall distance while actively flying so no
        // fall-damage accrues from the dive itself.
        player.setFallDistance(0f);
    }

    public void stopFlight(Player player) {
        UUID uid = player.getUniqueId();
        BukkitTask task = flightTasks.remove(uid);
        if (task != null) task.cancel();
        currentSpeed.remove(uid);

        // Brief landing-frame grace window for fall-damage cancellation —
        // NOT a standing immunity. Cleared automatically shortly after.
        recentlyFlying.add(uid);
        plugin.getServer().getScheduler().runTaskLater(plugin,
            () -> recentlyFlying.remove(uid), 10L);
    }

    public void cancelAll() {
        for (BukkitTask task : flightTasks.values()) {
            task.cancel();
        }
        flightTasks.clear();
        currentSpeed.clear();
        recentlyFlying.clear();
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    /**
     * Distance from the player's current location straight down to the
     * nearest solid block below them, via a downward ray trace. Returns
     * Double.MAX_VALUE if nothing solid is found within range (i.e.
     * definitely high enough to fly).
     */
    private double distanceToGround(Player player) {
        World world = player.getWorld();
        Location start = player.getLocation();
        RayTraceResult result = world.rayTraceBlocks(start, new Vector(0, -1, 0),
            320.0, FluidCollisionMode.NEVER, true);
        if (result == null || result.getHitPosition() == null) {
            return Double.MAX_VALUE;
        }
        return start.getY() - result.getHitPosition().getY();
    }

    private boolean isInLiquid(Player player) {
        return isLiquid(player.getLocation().getBlock().getType())
            || isLiquid(player.getEyeLocation().getBlock().getType());
    }

    private boolean isLiquid(Material m) {
        return m == Material.WATER || m == Material.LAVA;
    }

    private void spawnTrailParticles(Player player) {
        Location loc = player.getLocation().add(0, 1.0, 0);
        World world = loc.getWorld();
        world.spawnParticle(Particle.CLOUD, loc, 2, 0.25, 0.15, 0.25, 0.01);
        world.spawnParticle(Particle.END_ROD, loc, 1, 0.2, 0.1, 0.2, 0.005);
    }

    private void playLandingEffect(Player player) {
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.CLOUD, loc, 8, 0.4, 0.1, 0.4, 0.05);
        loc.getWorld().playSound(loc, Sound.BLOCK_WOOL_STEP, 0.8f, 1.2f);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
