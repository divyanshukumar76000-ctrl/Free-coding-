package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * §5 Ender Effect
 *
 * PASSIVE – Void Corruption:
 *   Every 10 successful hits on any target:
 *     - Visual void-lightning strike on target
 *     - 1-second stun (Slowness 255 + Weakness 255 + JumpBoost 128)
 *     - True damage (configurable)
 *     - Dragon-breath + Reverse-portal + End-rod particle burst
 *     - Passive aura: slow rotating dragon-breath wisps around player
 *
 * ACTIVE – Abyss Domain (12s, 180s CD):
 *   - 15-block void zone centred on player
 *   - Enemies: Blindness, Weakness II, Glowing, True DOT every second
 *   - Suppresses Teleport / Shield / Regen abilities for enemies inside
 *   - Void lightning every 2 s on a random enemy (true damage)
 *   - Rotating dragon-breath energy rings + ground void coverage
 *   - Collapses with a void explosion after duration
 */
public class EnderAbility implements Ability {

    @Override
    public PotionType type() { return PotionType.ENDER; }

    // ── Equip / Unequip ───────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        startPassiveAura(plugin, player);
        if (!PotionUtils.isQuiet()) {
            player.sendMessage(PotionUtils.colorize("&8☠ &5Void Corruption passive active."));
        }
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        plugin.getEnderDomainManager().endDomain(player);
    }

    // ── Passive: Void Corruption (every 10 hits) ──────────────────────────

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        int count = plugin.getHitCounterManager().registerHit(
            player.getUniqueId(), type(), target.getUniqueId(),
            player.getWorld().getFullTime());
        if (count == -1) return;

        // Small flicker every hit
        target.getWorld().spawnParticle(Particle.DRAGON_BREATH,
            target.getLocation().add(0,1,0), 3, 0.2,0.3,0.2, 0.02);

        int threshold = plugin.getConfig().getInt("potions.ender.passive-hits", 10);
        if (count >= threshold) {
            plugin.getHitCounterManager().reset(player.getUniqueId(), type());
            triggerVoidCorruption(plugin, player, target);
        }
    }

    private void triggerVoidCorruption(PotionSMP plugin, Player player, LivingEntity target) {
        Location loc  = target.getLocation();
        World    world = target.getWorld();
        double trueDmg = plugin.getConfig().getDouble("potions.ender.passive-true-damage", 6.0);

        // True damage
        target.damage(trueDmg, player);
        target.setNoDamageTicks(0);

        // 1-second stun
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,  25, 255, false, false));
        target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS,  25, 255, false, false));
        target.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST,25, 128, false, false));

        // Void lightning visual
        world.strikeLightningEffect(loc);

        // Burst particles
        world.spawnParticle(Particle.DRAGON_BREATH,  loc.clone().add(0,1,0), 30, 0.5,0.8,0.5, 0.05);
        world.spawnParticle(Particle.REVERSE_PORTAL, loc.clone().add(0,1,0), 20, 0.4,0.6,0.4, 0.1);
        world.spawnParticle(Particle.END_ROD,         loc.clone().add(0,2,0), 15, 0.3,0.5,0.3, 0.15);
        world.spawnParticle(Particle.PORTAL,          loc.clone().add(0,1,0), 25, 0.4,0.6,0.4, 0.3);

        world.playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL,    0.8f, 0.8f);
        world.playSound(loc, Sound.BLOCK_END_PORTAL_SPAWN,        0.6f, 0.7f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 0.3f);

        player.sendMessage(PotionUtils.colorize("&5☠ Void Corruption on &8" + target.getName() + "&5!"));
        if (target instanceof Player p)
            p.sendMessage(PotionUtils.colorize("&5☠ Void Corruption strikes you!"));
    }

    // ── Passive aura ──────────────────────────────────────────────────────

    private void startPassiveAura(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        new BukkitRunnable() {
            double angle = 0;
            @Override
            public void run() {
                if (!player.isOnline() ||
                    !plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.ENDER)) {
                    cancel(); return;
                }
                Location loc = player.getLocation().add(0, 1, 0);
                angle += 0.2;
                for (int i = 0; i < 3; i++) {
                    double a = angle + (Math.PI * 2 / 3) * i;
                    Location p = loc.clone().add(Math.cos(a)*1.0, 0.2*Math.sin(angle*2), Math.sin(a)*1.0);
                    loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, p, 1, 0,0,0, 0.01);
                }
                if (Math.random() < 0.3)
                    loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc, 1, 0.3,0.3,0.3, 0.05);
                if (Math.random() < 0.2)
                    loc.getWorld().spawnParticle(Particle.END_ROD, loc, 1, 0.4,0.6,0.4, 0.05);
            }
        }.runTaskTimer(plugin, 0L, 3L);
    }

    // ── Active: Abyss Domain ──────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        int cooldown = plugin.getConfig().getInt("potions.ender.active-cooldown", 180);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);
        plugin.getEnderDomainManager().startDomain(player);
        return ActivationResult.SUCCESS;
    }
}
