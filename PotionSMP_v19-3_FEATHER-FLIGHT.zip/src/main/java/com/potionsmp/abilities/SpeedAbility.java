package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * §e Speed Potion – Lightning Fast Warrior
 *
 * PASSIVE:
 * - Base Speed I always active
 * - Every hit → +1 Speed level (max Speed IV)
 * - No hit for 1.5s → reset to Speed I
 * - 25% reduced iframes on hit targets
 *
 * ACTIVE – Lightning Dash:
 * - Dash in look direction
 * - Speed IV during dash
 * - 20% damage reduction
 * - Shockwave at end (4-5 block radius)
 * - Duration: 1.8s | Cooldown: 28s
 */
public class SpeedAbility implements Ability, Listener {

    // Hit stacks per player (1–4)
    private final Map<UUID, Integer> speedStacks   = new HashMap<>();
    // Last hit timestamp
    private final Map<UUID, Long>    lastHitTime   = new HashMap<>();
    // Players currently dashing
    private final Set<UUID>          dashing        = new HashSet<>();
    // Pending "restore passive Speed" tasks — keyed so a newer temporary
    // Speed boost (burst OR dash) always supersedes an older one instead
    // of both fighting over the player's Speed effect.
    private final Map<UUID, BukkitTask> pendingSpeedRestore = new HashMap<>();

    private static final long STACK_RESET_MS = 1500;
    private static final int  MAX_STACKS     = 4;
    // Speed IV (5th perfect hit) now lasts exactly 3 seconds instead of
    // being permanent.
    private static final int  SPEED_IV_BURST_TICKS = 60;

    public void register(PotionSMP plugin) {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public PotionType type() { return PotionType.SPEED; }

    // ── Equip / Unequip ───────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        applySpeed(player, 1);
        startStackDecayLoop(plugin, player);
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        speedStacks.remove(uid);
        lastHitTime.remove(uid);
        dashing.remove(uid);
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();
        player.removePotionEffect(PotionEffectType.SPEED);
    }

    // ── Cleanup on quit / death — Multiple Dash Fix ────────────────────────
    // Ensures "dashing" (and related temp-boost state) can never get stuck
    // if the player disconnects or dies mid-dash.

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uid = event.getPlayer().getUniqueId();
        dashing.remove(uid);
        speedStacks.remove(uid);
        lastHitTime.remove(uid);
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        // Only clear the in-progress dash flag — hit-combo/passive state
        // is left alone here since respawn/equip handling already governs
        // that elsewhere, and touching it would be a gameplay change.
        dashing.remove(event.getEntity().getUniqueId());
    }

    // ── Stack decay loop: check every 5 ticks ────────────────────────────

    private void startStackDecayLoop(PotionSMP plugin, Player player) {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() ||
                    !plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.SPEED)) {
                    cancel(); return;
                }
                UUID uid = player.getUniqueId();
                Long last = lastHitTime.get(uid);
                if (last != null && System.currentTimeMillis() - last > STACK_RESET_MS) {
                    speedStacks.put(uid, 1);
                    lastHitTime.remove(uid);
                    // Don't stomp an active temporary boost (Speed IV burst
                    // or Dash) — its own restore task will apply the
                    // correct (now-decayed) passive level once it ends.
                    if (!pendingSpeedRestore.containsKey(uid)) {
                        applySpeed(player, 1);
                    }
                }
            }
        }.runTaskTimer(plugin, 5L, 5L);
    }

    // ── Passive hit: stack speed ──────────────────────────────────────────

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        UUID uid = player.getUniqueId();
        lastHitTime.put(uid, System.currentTimeMillis());

        int stacks = speedStacks.getOrDefault(uid, 1);
        stacks = Math.min(stacks + 1, MAX_STACKS);
        speedStacks.put(uid, stacks);

        if (stacks == MAX_STACKS) {
            // 5th perfect hit → Speed IV, but only for 3 seconds — not
            // Integer.MAX_VALUE anymore. Auto-restores the correct passive
            // level afterward via applyTemporarySpeed().
            applyTemporarySpeed(plugin, player, MAX_STACKS - 1, SPEED_IV_BURST_TICKS);
        } else {
            applySpeed(player, stacks);
        }

        // Reduce iframes by 25% (set to 75% of default 20)
        target.setNoDamageTicks(Math.max(0, (int)(target.getNoDamageTicks() * 0.75)));

        // Spark on hit
        target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,
            target.getLocation().add(0,1,0), 4, 0.2,0.2,0.2, 0.05);

        if (stacks == MAX_STACKS) {
            player.sendActionBar(net.kyori.adventure.text.Component.text("§e⚡ MAX SPEED!"));
        }
    }

    private void applySpeed(Player player, int level) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,
            Integer.MAX_VALUE, level - 1, false, false));
    }

    /**
     * Applies a TIME-LIMITED Speed effect (never Integer.MAX_VALUE) and
     * schedules a restore of the player's correct passive Speed level once
     * it naturally expires. Shared by both the 5th-hit Speed IV burst and
     * Dash's own Speed IV so neither one permanently loses/overwrites the
     * hit-combo passive level — a newer temporary boost always cancels and
     * replaces any older pending restore.
     */
    private void applyTemporarySpeed(PotionSMP plugin, Player player, int amplifier, int durationTicks) {
        UUID uid = player.getUniqueId();

        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();

        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, durationTicks, amplifier, false, false));

        BukkitTask restore = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            pendingSpeedRestore.remove(uid);
            if (!player.isOnline()) return;
            if (!plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) return;

            // Correct passive level — capped below MAX_STACKS so Speed IV
            // is never handed back out as a permanent effect, only ever
            // as a fresh temporary burst/dash.
            int level = Math.min(speedStacks.getOrDefault(uid, 1), MAX_STACKS - 1);
            applySpeed(player, level);
        }, durationTicks);

        pendingSpeedRestore.put(uid, restore);
    }

    // ── Active: Lightning Dash ────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        // Hard guard: never allow a second dash while one is already
        // active — checked independently of cooldown timing/config so it
        // can't be bypassed even with a custom short cooldown value.
        if (dashing.contains(uid)) return ActivationResult.ON_COOLDOWN;

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        int cooldown = plugin.getConfig().getInt("potions.speed.active-cooldown", 28);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

        executeDash(plugin, player);
        return ActivationResult.SUCCESS;
    }

    private void executeDash(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        dashing.add(uid);

        // Speed IV + 20% damage reduction during dash. Speed IV is applied
        // as a temporary boost (via applyTemporarySpeed) so the player's
        // correct passive Speed level is automatically restored once the
        // dash's speed window ends, instead of being left with no Speed
        // effect at all.
        applyTemporarySpeed(plugin, player, 3, 40);
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,  40, 0, false, false));

        // Launch in look direction
        Vector dir = player.getLocation().getDirection().normalize().multiply(1.4);
        dir.setY(Math.max(dir.getY(), 0.1));
        player.setVelocity(dir);

        player.sendTitle("", "§e⚡ Lightning Dash!", 2, 15, 5);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.8f);

        // Dash trail
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= 36 || !player.isOnline() || player.isDead() || !dashing.contains(uid)) { // 1.8s
                    if (player.isOnline() && !player.isDead()) {
                        triggerShockwave(plugin, player);
                        player.removePotionEffect(PotionEffectType.RESISTANCE);
                    }
                    dashing.remove(uid);
                    cancel(); return;
                }
                Location loc = player.getLocation();
                loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 5, 0.2,0.2,0.2, 0.05);
                loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK,   loc, 2, 0.3,0.1,0.3, 0);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void triggerShockwave(PotionSMP plugin, Player player) {
        Location loc = player.getLocation();
        World world  = loc.getWorld();
        double radius = plugin.getConfig().getDouble("potions.speed.shockwave-radius", 4.5);
        double dmg    = plugin.getConfig().getDouble("potions.speed.shockwave-damage", 5.0);

        // Ring particles
        for (int i = 0; i < 36; i++) {
            double angle = Math.toRadians(i * 10);
            Location p = loc.clone().add(Math.cos(angle)*radius, 0.1, Math.sin(angle)*radius);
            world.spawnParticle(Particle.ELECTRIC_SPARK, p, 2, 0.1,0.1,0.1, 0.05);
            world.spawnParticle(Particle.SWEEP_ATTACK,   p, 1, 0,0,0, 0);
        }

        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.4f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.5f);

        // Damage + knockback nearby
        for (Entity e : world.getNearbyEntities(loc, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(player.getUniqueId())) continue;
            le.damage(dmg, player);
            le.setNoDamageTicks(0);
            Vector kb = le.getLocation().toVector().subtract(loc.toVector()).normalize()
                .multiply(1.5).setY(0.5);
            le.setVelocity(kb);
        }
    }

    // ── Reduce iframes on victim (EntityDamageByEntityEvent) ─────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (!speedStacks.containsKey(p.getUniqueId())) return;
        if (e.getEntity() instanceof LivingEntity le) {
            plugin_ref_hack(p).getServer().getScheduler().runTaskLater(
                plugin_ref_hack(p), () -> le.setNoDamageTicks(
                    (int)(le.getNoDamageTicks() * 0.75)), 1L);
        }
    }
    // Small helper to get plugin ref without storing it (pattern: use getInstance)
    private PotionSMP plugin_ref_hack(Player p) { return PotionSMP.getInstance(); }
}
